import React from 'react';
import { useMeals } from '../../hooks/useMeals';
import { format } from 'date-fns';
import { Edit3, Trash2, Clock } from 'lucide-react';
import type { Database } from '../../lib/supabase';

type Meal = Database['public']['Tables']['meals']['Row'];

interface MealCardProps {
  meal: Meal;
  onEdit: (meal: Meal) => void;
}

export function MealCard({ meal, onEdit }: MealCardProps) {
  const { deleteMeal } = useMeals();

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this meal?')) {
      try {
        await deleteMeal(meal.id);
      } catch (error) {
        console.error('Failed to delete meal:', error);
      }
    }
  };

  const mealTypeColors: Record<string, string> = {
    breakfast: 'bg-yellow-100 text-yellow-800',
    lunch: 'bg-green-100 text-green-800',
    dinner: 'bg-orange-100 text-orange-800',
    snack: 'bg-purple-100 text-purple-800',
  };

  const mealTypeEmojis: Record<string, string> = {
    breakfast: '🌅',
    lunch: '🌞',
    dinner: '🌙',
    snack: '🍿',
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-200 transform hover:-translate-y-1">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-3">
            <h3 className="text-xl font-bold text-gray-900">{meal.name}</h3>
            <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${mealTypeColors[meal.meal_type] || mealTypeColors.snack}`}>
              <span>{mealTypeEmojis[meal.meal_type] || '🍽️'}</span>
              {meal.meal_type}
            </span>
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-3">
            <div className="bg-blue-50 p-3 rounded-lg">
              <p className="text-sm text-blue-600 font-medium">Calories</p>
              <p className="text-lg font-bold text-blue-700">{meal.calories}</p>
            </div>
            <div className="bg-emerald-50 p-3 rounded-lg">
              <p className="text-sm text-emerald-600 font-medium">Protein</p>
              <p className="text-lg font-bold text-emerald-700">{meal.protein}g</p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-3">
            <div className="bg-orange-50 p-3 rounded-lg">
              <p className="text-sm text-orange-600 font-medium">Carbs</p>
              <p className="text-lg font-bold text-orange-700">{meal.carbs}g</p>
            </div>
            <div className="bg-purple-50 p-3 rounded-lg">
              <p className="text-sm text-purple-600 font-medium">Fat</p>
              <p className="text-lg font-bold text-purple-700">{meal.fat}g</p>
            </div>
          </div>

          <p className="text-sm text-gray-600 flex items-center gap-1">
            <Clock className="w-4 h-4" />
            {format(new Date(meal.date), 'MMMM dd, yyyy')}
          </p>
        </div>
        
        <div className="flex items-center gap-2 ml-4">
          <button
            onClick={() => onEdit(meal)}
            className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            title="Edit meal"
          >
            <Edit3 className="w-4 h-4" />
          </button>
          <button
            onClick={handleDelete}
            className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            title="Delete meal"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}