import React, { useState } from 'react';
import { useMeals } from '../../hooks/useMeals';
import { MealForm } from './MealForm';
import { MealCard } from './MealCard';
import { Plus, Utensils } from 'lucide-react';

export function MealList() {
  const { meals, loading } = useMeals();
  const [showForm, setShowForm] = useState(false);
  const [editingMeal, setEditingMeal] = useState<any>(null);

  const handleEdit = (meal: any) => {
    setEditingMeal(meal);
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingMeal(null);
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded-lg"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Utensils className="w-8 h-8 text-blue-600" />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">My Meals</h1>
            <p className="text-gray-600">Log your meals and track nutrition</p>
          </div>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white px-6 py-3 rounded-lg font-semibold hover:from-blue-600 hover:to-purple-600 transition-all duration-200 shadow-lg hover:shadow-xl"
        >
          <Plus className="w-5 h-5" />
          Add Meal
        </button>
      </div>

      {showForm && (
        <MealForm
          meal={editingMeal}
          onClose={handleCloseForm}
        />
      )}

      {meals.length === 0 ? (
        <div className="text-center py-12">
          <Utensils className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No meals logged yet</h3>
          <p className="text-gray-600 mb-6">Start tracking your nutrition by adding your first meal.</p>
          <button
            onClick={() => setShowForm(true)}
            className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-500 to-purple-500 text-white px-6 py-3 rounded-lg font-semibold hover:from-blue-600 hover:to-purple-600 transition-all duration-200"
          >
            <Plus className="w-5 h-5" />
            Log Your First Meal
          </button>
        </div>
      ) : (
        <div className="grid gap-4">
          {meals.map((meal) => (
            <MealCard
              key={meal.id}
              meal={meal}
              onEdit={handleEdit}
            />
          ))}
        </div>
      )}
    </div>
  );
}