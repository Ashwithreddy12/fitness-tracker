import React from 'react';
import { useGoals } from '../../hooks/useGoals';
import { format } from 'date-fns';
import { Edit3, Trash2, Calendar, CheckCircle, Target } from 'lucide-react';
import type { Goal } from '../../hooks/useGoals';

interface GoalCardProps {
  goal: Goal;
  onEdit: (goal: Goal) => void;
}

export function GoalCard({ goal, onEdit }: GoalCardProps) {
  const { deleteGoal, updateGoal } = useGoals();

  const handleDelete = async () => {
    if (window.confirm('Are you sure you want to delete this goal?')) {
      try {
        await deleteGoal(goal.id);
      } catch (error) {
        console.error('Failed to delete goal:', error);
      }
    }
  };

  const handleToggleComplete = async () => {
    try {
      await updateGoal(goal.id, { 
        completed: !goal.completed,
        current_value: goal.completed ? 0 : goal.target_value
      });
    } catch (error) {
      console.error('Failed to update goal:', error);
    }
  };

  const progress = Math.min((goal.current_value / goal.target_value) * 100, 100);
  const isOverdue = new Date(goal.deadline) < new Date() && !goal.completed;

  const categoryColors: Record<string, string> = {
    workout: 'bg-emerald-100 text-emerald-800',
    nutrition: 'bg-blue-100 text-blue-800',
    weight: 'bg-orange-100 text-orange-800',
    custom: 'bg-purple-100 text-purple-800',
  };

  return (
    <div className={`bg-white rounded-xl shadow-lg p-6 border transition-all duration-200 transform hover:-translate-y-1 ${
      goal.completed ? 'border-emerald-200 bg-emerald-50' : isOverdue ? 'border-red-200' : 'border-gray-100 hover:shadow-xl'
    }`}>
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2">
            <h3 className={`text-xl font-bold ${goal.completed ? 'text-emerald-700' : 'text-gray-900'}`}>
              {goal.title}
            </h3>
            <span className={`px-3 py-1 rounded-full text-xs font-medium ${categoryColors[goal.category]}`}>
              {goal.category}
            </span>
            {goal.completed && <CheckCircle className="w-5 h-5 text-emerald-500" />}
          </div>
          
          <p className="text-gray-600 mb-4">{goal.description}</p>
          
          <div className="space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-600">Progress</span>
              <span className={`font-semibold ${goal.completed ? 'text-emerald-600' : 'text-gray-900'}`}>
                {goal.current_value} / {goal.target_value} {goal.unit}
              </span>
            </div>
            
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div 
                className={`h-2 rounded-full transition-all duration-300 ${
                  goal.completed ? 'bg-emerald-500' : 'bg-gradient-to-r from-purple-500 to-pink-500'
                }`}
                style={{ width: `${progress}%` }}
              ></div>
            </div>
            
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1 text-gray-600">
                <Calendar className="w-4 h-4" />
                <span>Due: {format(new Date(goal.deadline), 'MMM dd, yyyy')}</span>
              </div>
              {isOverdue && (
                <span className="text-red-600 font-medium">Overdue</span>
              )}
            </div>
          </div>
        </div>
        
        <div className="flex items-center gap-2 ml-4">
          <button
            onClick={handleToggleComplete}
            className={`p-2 rounded-lg transition-colors ${
              goal.completed 
                ? 'text-emerald-600 hover:bg-emerald-100' 
                : 'text-gray-500 hover:text-emerald-600 hover:bg-emerald-50'
            }`}
            title={goal.completed ? 'Mark as incomplete' : 'Mark as complete'}
          >
            <CheckCircle className="w-5 h-5" />
          </button>
          <button
            onClick={() => onEdit(goal)}
            className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            title="Edit goal"
          >
            <Edit3 className="w-4 h-4" />
          </button>
          <button
            onClick={handleDelete}
            className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            title="Delete goal"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}