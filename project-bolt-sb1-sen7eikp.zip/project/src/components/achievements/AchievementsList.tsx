import React from 'react';
import { useWorkouts } from '../../hooks/useWorkouts';
import { useMeals } from '../../hooks/useMeals';
import { useGoals } from '../../hooks/useGoals';
import { Trophy, Award, Star, Target, Calendar, Flame } from 'lucide-react';

export function AchievementsList() {
  const { workouts } = useWorkouts();
  const { meals } = useMeals();
  const { goals } = useGoals();

  // Calculate achievements
  const totalWorkouts = workouts.length;
  const totalMeals = meals.length;
  const completedGoals = goals.filter(g => g.completed).length;
  const totalCaloriesBurned = workouts.reduce((sum, w) => sum + w.calories_burned, 0);
  const totalCaloriesLogged = meals.reduce((sum, m) => sum + m.calories, 0);

  const achievements = [
    {
      id: 'first-workout',
      title: 'First Steps',
      description: 'Complete your first workout',
      icon: Target,
      unlocked: totalWorkouts >= 1,
      progress: Math.min(totalWorkouts, 1),
      target: 1,
      color: 'emerald',
    },
    {
      id: 'workout-streak',
      title: 'Workout Warrior',
      description: 'Complete 10 workouts',
      icon: Trophy,
      unlocked: totalWorkouts >= 10,
      progress: Math.min(totalWorkouts, 10),
      target: 10,
      color: 'blue',
    },
    {
      id: 'calorie-burner',
      title: 'Calorie Crusher',
      description: 'Burn 1000 calories total',
      icon: Flame,
      unlocked: totalCaloriesBurned >= 1000,
      progress: Math.min(totalCaloriesBurned, 1000),
      target: 1000,
      color: 'orange',
    },
    {
      id: 'meal-tracker',
      title: 'Nutrition Navigator',
      description: 'Log 25 meals',
      icon: Award,
      unlocked: totalMeals >= 25,
      progress: Math.min(totalMeals, 25),
      target: 25,
      color: 'green',
    },
    {
      id: 'goal-achiever',
      title: 'Goal Getter',
      description: 'Complete 3 goals',
      icon: Star,
      unlocked: completedGoals >= 3,
      progress: Math.min(completedGoals, 3),
      target: 3,
      color: 'purple',
    },
    {
      id: 'consistency-king',
      title: 'Consistency King',
      description: 'Complete 50 workouts',
      icon: Calendar,
      unlocked: totalWorkouts >= 50,
      progress: Math.min(totalWorkouts, 50),
      target: 50,
      color: 'indigo',
    },
  ];

  const unlockedAchievements = achievements.filter(a => a.unlocked);
  const lockedAchievements = achievements.filter(a => !a.unlocked);

  const colorClasses = {
    emerald: 'from-emerald-500 to-emerald-600 bg-emerald-50 text-emerald-600',
    blue: 'from-blue-500 to-blue-600 bg-blue-50 text-blue-600',
    orange: 'from-orange-500 to-orange-600 bg-orange-50 text-orange-600',
    green: 'from-green-500 to-green-600 bg-green-50 text-green-600',
    purple: 'from-purple-500 to-purple-600 bg-purple-50 text-purple-600',
    indigo: 'from-indigo-500 to-indigo-600 bg-indigo-50 text-indigo-600',
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <div className="text-center">
        <Trophy className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Achievements</h1>
        <p className="text-gray-600">Celebrate your fitness milestones</p>
      </div>

      {/* Achievement Stats */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
        <h2 className="text-xl font-bold text-gray-900 mb-4">Your Progress</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-emerald-600">{unlockedAchievements.length}</div>
            <div className="text-sm text-gray-600">Unlocked</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-600">{totalWorkouts}</div>
            <div className="text-sm text-gray-600">Workouts</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-600">{totalCaloriesBurned}</div>
            <div className="text-sm text-gray-600">Calories Burned</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-600">{completedGoals}</div>
            <div className="text-sm text-gray-600">Goals Completed</div>
          </div>
        </div>
      </div>

      {/* Unlocked Achievements */}
      {unlockedAchievements.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-4">Unlocked Achievements ({unlockedAchievements.length})</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {unlockedAchievements.map((achievement) => {
              const Icon = achievement.icon;
              const colors = colorClasses[achievement.color as keyof typeof colorClasses];
              
              return (
                <div key={achievement.id} className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-yellow-400 to-yellow-500 rounded-bl-full flex items-center justify-center">
                    <Trophy className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex items-start gap-4">
                    <div className={`p-3 rounded-lg ${colors.split(' ')[2]} ${colors.split(' ')[3]}`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-gray-900 mb-1">{achievement.title}</h3>
                      <p className="text-sm text-gray-600 mb-3">{achievement.description}</p>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full bg-gradient-to-r ${colors.split(' ')[0]} ${colors.split(' ')[1]}`}
                            style={{ width: '100%' }}
                          ></div>
                        </div>
                        <span className="text-xs font-medium text-gray-600">
                          {achievement.progress}/{achievement.target}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Locked Achievements */}
      {lockedAchievements.length > 0 && (
        <div>
          <h2 className="text-xl font-bold text-gray-900 mb-4">In Progress ({lockedAchievements.length})</h2>
          <div className="grid gap-4 md:grid-cols-2">
            {lockedAchievements.map((achievement) => {
              const Icon = achievement.icon;
              const progress = (achievement.progress / achievement.target) * 100;
              
              return (
                <div key={achievement.id} className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 opacity-75">
                  <div className="flex items-start gap-4">
                    <div className="p-3 rounded-lg bg-gray-100">
                      <Icon className="w-6 h-6 text-gray-400" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-lg font-bold text-gray-700 mb-1">{achievement.title}</h3>
                      <p className="text-sm text-gray-500 mb-3">{achievement.description}</p>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div 
                            className="h-2 rounded-full bg-gray-400 transition-all duration-300"
                            style={{ width: `${progress}%` }}
                          ></div>
                        </div>
                        <span className="text-xs font-medium text-gray-500">
                          {achievement.progress}/{achievement.target}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {achievements.length === 0 && (
        <div className="text-center py-12">
          <Trophy className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-900 mb-2">No achievements yet</h3>
          <p className="text-gray-600">Start working out and logging meals to unlock achievements!</p>
        </div>
      )}
    </div>
  );
}