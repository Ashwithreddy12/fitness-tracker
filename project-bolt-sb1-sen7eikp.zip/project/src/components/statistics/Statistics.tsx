import React, { useState } from 'react';
import { useWorkouts } from '../../hooks/useWorkouts';
import { useMeals } from '../../hooks/useMeals';
import { useGoals } from '../../hooks/useGoals';
import { BarChart3, TrendingUp, Calendar, Filter } from 'lucide-react';
import { format, subDays, startOfWeek, endOfWeek, startOfMonth, endOfMonth } from 'date-fns';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LineChart, Line, PieChart, Pie, Cell } from 'recharts';

export function Statistics() {
  const { workouts } = useWorkouts();
  const { meals } = useMeals();
  const { goals } = useGoals();
  const [timeRange, setTimeRange] = useState<'week' | 'month' | 'all'>('week');

  const today = new Date();
  const weekStart = startOfWeek(today);
  const weekEnd = endOfWeek(today);
  const monthStart = startOfMonth(today);
  const monthEnd = endOfMonth(today);

  const getFilteredData = () => {
    let filteredWorkouts = workouts;
    let filteredMeals = meals;

    if (timeRange === 'week') {
      filteredWorkouts = workouts.filter(w => {
        const date = new Date(w.date);
        return date >= weekStart && date <= weekEnd;
      });
      filteredMeals = meals.filter(m => {
        const date = new Date(m.date);
        return date >= weekStart && date <= weekEnd;
      });
    } else if (timeRange === 'month') {
      filteredWorkouts = workouts.filter(w => {
        const date = new Date(w.date);
        return date >= monthStart && date <= monthEnd;
      });
      filteredMeals = meals.filter(m => {
        const date = new Date(m.date);
        return date >= monthStart && date <= monthEnd;
      });
    }

    return { filteredWorkouts, filteredMeals };
  };

  const { filteredWorkouts, filteredMeals } = getFilteredData();

  // Workout Statistics
  const workoutStats = {
    total: filteredWorkouts.length,
    totalDuration: filteredWorkouts.reduce((sum, w) => sum + w.duration_minutes, 0),
    totalCalories: filteredWorkouts.reduce((sum, w) => sum + w.calories_burned, 0),
    avgDuration: filteredWorkouts.length > 0 ? Math.round(filteredWorkouts.reduce((sum, w) => sum + w.duration_minutes, 0) / filteredWorkouts.length) : 0,
    avgCalories: filteredWorkouts.length > 0 ? Math.round(filteredWorkouts.reduce((sum, w) => sum + w.calories_burned, 0) / filteredWorkouts.length) : 0,
  };

  // Exercise type distribution
  const exerciseTypes = filteredWorkouts.reduce((acc, workout) => {
    acc[workout.exercise_type] = (acc[workout.exercise_type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const exerciseTypeData = Object.entries(exerciseTypes).map(([type, count]) => ({
    name: type,
    value: count,
  }));

  // Meal Statistics
  const mealStats = {
    total: filteredMeals.length,
    totalCalories: filteredMeals.reduce((sum, m) => sum + m.calories, 0),
    totalProtein: filteredMeals.reduce((sum, m) => sum + m.protein, 0),
    totalCarbs: filteredMeals.reduce((sum, m) => sum + m.carbs, 0),
    totalFat: filteredMeals.reduce((sum, m) => sum + m.fat, 0),
    avgCalories: filteredMeals.length > 0 ? Math.round(filteredMeals.reduce((sum, m) => sum + m.calories, 0) / filteredMeals.length) : 0,
  };

  // Daily trend data
  const days = timeRange === 'week' ? 7 : timeRange === 'month' ? 30 : 90;
  const trendData = Array.from({ length: days }, (_, i) => {
    const date = subDays(today, days - 1 - i);
    const dateString = format(date, 'yyyy-MM-dd');
    
    const dayWorkouts = workouts.filter(w => w.date === dateString);
    const dayMeals = meals.filter(m => m.date === dateString);
    
    return {
      date: format(date, timeRange === 'week' ? 'EEE' : 'MMM dd'),
      workouts: dayWorkouts.length,
      calories_burned: dayWorkouts.reduce((sum, w) => sum + w.calories_burned, 0),
      calories_consumed: dayMeals.reduce((sum, m) => sum + m.calories, 0),
    };
  });

  const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#8b5cf6', '#ef4444', '#06b6d4'];

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <BarChart3 className="w-8 h-8 text-indigo-600" />
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Statistics</h1>
            <p className="text-gray-600">Detailed insights into your fitness journey</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-gray-500" />
          <select
            value={timeRange}
            onChange={(e) => setTimeRange(e.target.value as any)}
            className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          >
            <option value="week">This Week</option>
            <option value="month">This Month</option>
            <option value="all">All Time</option>
          </select>
        </div>
      </div>

      {/* Overview Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl shadow-lg p-4 border border-gray-100">
          <div className="text-2xl font-bold text-emerald-600">{workoutStats.total}</div>
          <div className="text-sm text-gray-600">Total Workouts</div>
        </div>
        <div className="bg-white rounded-xl shadow-lg p-4 border border-gray-100">
          <div className="text-2xl font-bold text-blue-600">{workoutStats.totalDuration}</div>
          <div className="text-sm text-gray-600">Minutes Exercised</div>
        </div>
        <div className="bg-white rounded-xl shadow-lg p-4 border border-gray-100">
          <div className="text-2xl font-bold text-orange-600">{workoutStats.totalCalories}</div>
          <div className="text-sm text-gray-600">Calories Burned</div>
        </div>
        <div className="bg-white rounded-xl shadow-lg p-4 border border-gray-100">
          <div className="text-2xl font-bold text-purple-600">{mealStats.total}</div>
          <div className="text-sm text-gray-600">Meals Logged</div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Daily Activity Trend */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Daily Activity Trend</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" stroke="#6b7280" fontSize={12} />
                <YAxis stroke="#6b7280" fontSize={12} />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="workouts" stroke="#10b981" strokeWidth={2} name="Workouts" />
                <Line type="monotone" dataKey="calories_burned" stroke="#3b82f6" strokeWidth={2} name="Calories Burned" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Exercise Type Distribution */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Exercise Types</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={exerciseTypeData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {exerciseTypeData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Calorie Balance */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Calorie Balance</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="date" stroke="#6b7280" fontSize={12} />
                <YAxis stroke="#6b7280" fontSize={12} />
                <Tooltip />
                <Legend />
                <Bar dataKey="calories_consumed" fill="#3b82f6" name="Consumed" />
                <Bar dataKey="calories_burned" fill="#10b981" name="Burned" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Nutrition Breakdown */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Nutrition Summary</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Calories</span>
              <span className="font-bold text-blue-600">{mealStats.totalCalories}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Protein</span>
              <span className="font-bold text-emerald-600">{Math.round(mealStats.totalProtein)}g</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Carbs</span>
              <span className="font-bold text-orange-600">{Math.round(mealStats.totalCarbs)}g</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Fat</span>
              <span className="font-bold text-purple-600">{Math.round(mealStats.totalFat)}g</span>
            </div>
            <div className="pt-4 border-t">
              <div className="flex justify-between items-center">
                <span className="text-gray-600">Avg Calories/Meal</span>
                <span className="font-bold text-gray-900">{mealStats.avgCalories}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Stats */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Detailed Statistics</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <div className="space-y-3">
            <h4 className="font-semibold text-gray-700">Workout Performance</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Average Duration</span>
                <span className="font-medium">{workoutStats.avgDuration} min</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Average Calories</span>
                <span className="font-medium">{workoutStats.avgCalories} cal</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Total Duration</span>
                <span className="font-medium">{Math.round(workoutStats.totalDuration / 60)} hours</span>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-gray-700">Nutrition Tracking</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Meals per Day</span>
                <span className="font-medium">{timeRange === 'week' ? Math.round(filteredMeals.length / 7) : timeRange === 'month' ? Math.round(filteredMeals.length / 30) : Math.round(filteredMeals.length / Math.max(1, (Date.now() - new Date(filteredMeals[filteredMeals.length - 1]?.created_at || Date.now()).getTime()) / (1000 * 60 * 60 * 24)))}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Avg Protein/Day</span>
                <span className="font-medium">{Math.round(mealStats.totalProtein / Math.max(1, timeRange === 'week' ? 7 : timeRange === 'month' ? 30 : 90))}g</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Calories/Day</span>
                <span className="font-medium">{Math.round(mealStats.totalCalories / Math.max(1, timeRange === 'week' ? 7 : timeRange === 'month' ? 30 : 90))}</span>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-semibold text-gray-700">Goals & Progress</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Total Goals</span>
                <span className="font-medium">{goals.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Completed</span>
                <span className="font-medium text-emerald-600">{goals.filter(g => g.completed).length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Success Rate</span>
                <span className="font-medium">{goals.length > 0 ? Math.round((goals.filter(g => g.completed).length / goals.length) * 100) : 0}%</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}