import React from 'react';
import { format, subDays, startOfWeek, endOfWeek } from 'date-fns';
import { useWorkouts } from '../../hooks/useWorkouts';
import { useMeals } from '../../hooks/useMeals';
import { useChallenges } from '../../hooks/useChallenges';
import { useGoals } from '../../hooks/useGoals';
import { StatsCard } from './StatsCard';
import { ProgressChart } from './ProgressChart';
import { ChallengeCard } from './ChallengeCard';
import { Activity, Apple, Target, TrendingUp, Zap, Trophy } from 'lucide-react';

export function Dashboard() {
  const { workouts } = useWorkouts();
  const { meals } = useMeals();
  const { challenges } = useChallenges();
  const { goals } = useGoals();

  const today = new Date();
  const weekStart = startOfWeek(today);
  const weekEnd = endOfWeek(today);

  // Calculate today's stats
  const todayString = format(today, 'yyyy-MM-dd');
  const todayWorkouts = workouts.filter(w => w.date === todayString);
  const todayMeals = meals.filter(m => m.date === todayString);
  
  const todayCaloriesBurned = todayWorkouts.reduce((sum, w) => sum + w.calories_burned, 0);
  const todayCaloriesConsumed = todayMeals.reduce((sum, m) => sum + m.calories, 0);
  const todayNetCalories = todayCaloriesConsumed - todayCaloriesBurned;

  // Calculate week's stats
  const weekWorkouts = workouts.filter(w => {
    const workoutDate = new Date(w.date);
    return workoutDate >= weekStart && workoutDate <= weekEnd;
  });
  
  const weekMeals = meals.filter(m => {
    const mealDate = new Date(m.date);
    return mealDate >= weekStart && mealDate <= weekEnd;
  });

  const weekCaloriesBurned = weekWorkouts.reduce((sum, w) => sum + w.calories_burned, 0);
  const weekCaloriesConsumed = weekMeals.reduce((sum, m) => sum + m.calories, 0);
  const weekWorkoutCount = weekWorkouts.length;

  // Goals and challenges stats
  const activeGoals = goals.filter(g => !g.completed);
  const todayChallenge = challenges.find(c => c.date === todayString);

  // Prepare chart data for the last 7 days
  const chartData = Array.from({ length: 7 }, (_, i) => {
    const date = subDays(today, 6 - i);
    const dateString = format(date, 'yyyy-MM-dd');
    
    const dayWorkouts = workouts.filter(w => w.date === dateString);
    const dayMeals = meals.filter(m => m.date === dateString);
    
    return {
      date: format(date, 'MMM dd'),
      caloriesBurned: dayWorkouts.reduce((sum, w) => sum + w.calories_burned, 0),
      caloriesConsumed: dayMeals.reduce((sum, m) => sum + m.calories, 0),
    };
  });

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-8">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">
          Welcome to Your Fitness Journey
        </h1>
        <p className="text-gray-600 text-lg">
          Track your progress and achieve your health goals
        </p>
      </div>

      {/* Today's Summary */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatsCard
          title="Calories Burned Today"
          value={todayCaloriesBurned}
          unit="cal"
          icon={Activity}
          color="emerald"
          trend={todayCaloriesBurned > 200 ? 'up' : 'neutral'}
        />
        <StatsCard
          title="Calories Consumed Today"
          value={todayCaloriesConsumed}
          unit="cal"
          icon={Apple}
          color="blue"
          trend={todayCaloriesConsumed < 2000 ? 'down' : 'up'}
        />
        <StatsCard
          title="Net Calories Today"
          value={Math.abs(todayNetCalories)}
          unit="cal"
          icon={Target}
          color={todayNetCalories > 0 ? 'orange' : 'emerald'}
          trend={todayNetCalories < 0 ? 'down' : 'up'}
          subtitle={todayNetCalories > 0 ? 'Surplus' : 'Deficit'}
        />
        <StatsCard
          title="Workouts This Week"
          value={weekWorkoutCount}
          unit="sessions"
          icon={TrendingUp}
          color="purple"
          trend={weekWorkoutCount >= 3 ? 'up' : 'neutral'}
        />
      </div>

      {/* Progress Chart */}
      <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Weekly Progress</h2>
        <ProgressChart data={chartData} />
      </div>

      {/* Daily Challenge & Goals */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Daily Challenge */}
        {todayChallenge && (
          <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
            <div className="flex items-center gap-3 mb-4">
              <Zap className="w-6 h-6 text-yellow-500" />
              <h3 className="text-xl font-bold text-gray-900">Today's Challenge</h3>
            </div>
            <ChallengeCard challenge={todayChallenge} />
          </div>
        )}

        {/* Active Goals Preview */}
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Trophy className="w-6 h-6 text-purple-500" />
              <h3 className="text-xl font-bold text-gray-900">Active Goals</h3>
            </div>
            <span className="text-sm text-gray-500">{activeGoals.length} active</span>
          </div>
          {activeGoals.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No active goals. Set some goals to track your progress!</p>
          ) : (
            <div className="space-y-3">
              {activeGoals.slice(0, 3).map((goal) => {
                const progress = (goal.current_value / goal.target_value) * 100;
                return (
                  <div key={goal.id} className="p-3 bg-gray-50 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <h4 className="font-medium text-gray-900">{goal.title}</h4>
                      <span className="text-xs text-gray-500">
                        {goal.current_value}/{goal.target_value} {goal.unit}
                      </span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className="h-2 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-300"
                        style={{ width: `${Math.min(progress, 100)}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
              {activeGoals.length > 3 && (
                <p className="text-xs text-gray-500 text-center">
                  +{activeGoals.length - 3} more goals
                </p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Weekly Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <h3 className="text-xl font-bold text-gray-900 mb-4">This Week's Summary</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Calories Burned</span>
              <span className="font-semibold text-emerald-600">{weekCaloriesBurned} cal</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Calories Consumed</span>
              <span className="font-semibold text-blue-600">{weekCaloriesConsumed} cal</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Workouts</span>
              <span className="font-semibold text-purple-600">{weekWorkoutCount} sessions</span>
            </div>
            <div className="flex justify-between items-center pt-2 border-t">
              <span className="text-gray-600 font-medium">Net Calories</span>
              <span className={`font-bold ${weekCaloriesConsumed - weekCaloriesBurned > 0 ? 'text-orange-600' : 'text-emerald-600'}`}>
                {Math.abs(weekCaloriesConsumed - weekCaloriesBurned)} cal {weekCaloriesConsumed - weekCaloriesBurned > 0 ? 'surplus' : 'deficit'}
              </span>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-lg p-6 border border-gray-100">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Recent Activity</h3>
          <div className="space-y-3">
            {[...todayWorkouts.slice(0, 2), ...todayMeals.slice(0, 2)].length === 0 ? (
              <p className="text-gray-500 text-center py-4">No activity today yet. Start tracking!</p>
            ) : (
              <>
                {todayWorkouts.slice(0, 2).map((workout) => (
                  <div key={workout.id} className="flex items-center gap-3 p-3 bg-emerald-50 rounded-lg">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{workout.name}</p>
                      <p className="text-sm text-gray-600">{workout.calories_burned} calories burned</p>
                    </div>
                  </div>
                ))}
                {todayMeals.slice(0, 2).map((meal) => (
                  <div key={meal.id} className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                    <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">{meal.name}</p>
                      <p className="text-sm text-gray-600">{meal.calories} calories</p>
                    </div>
                  </div>
                ))}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}