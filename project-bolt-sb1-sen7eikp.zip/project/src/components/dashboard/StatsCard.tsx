import React from 'react';
import { DivideIcon as LucideIcon, TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface StatsCardProps {
  title: string;
  value: number;
  unit: string;
  icon: LucideIcon;
  color: 'emerald' | 'blue' | 'orange' | 'purple';
  trend?: 'up' | 'down' | 'neutral';
  subtitle?: string;
}

export function StatsCard({ title, value, unit, icon: Icon, color, trend = 'neutral', subtitle }: StatsCardProps) {
  const colorClasses = {
    emerald: 'from-emerald-500 to-emerald-600 bg-emerald-50 text-emerald-600',
    blue: 'from-blue-500 to-blue-600 bg-blue-50 text-blue-600',
    orange: 'from-orange-500 to-orange-600 bg-orange-50 text-orange-600',
    purple: 'from-purple-500 to-purple-600 bg-purple-50 text-purple-600',
  };

  const trendIcons = {
    up: TrendingUp,
    down: TrendingDown,
    neutral: Minus,
  };

  const trendColors = {
    up: 'text-emerald-500',
    down: 'text-red-500',
    neutral: 'text-gray-400',
  };

  const TrendIcon = trendIcons[trend];

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-100 hover:shadow-xl transition-all duration-200 transform hover:-translate-y-1">
      <div className="flex items-center justify-between mb-4">
        <div className={`p-3 rounded-lg ${colorClasses[color].split(' ')[2]} ${colorClasses[color].split(' ')[3]}`}>
          <Icon className="w-6 h-6" />
        </div>
        <TrendIcon className={`w-5 h-5 ${trendColors[trend]}`} />
      </div>
      
      <div className="space-y-1">
        <p className="text-sm font-medium text-gray-600">{title}</p>
        <div className="flex items-baseline gap-2">
          <p className="text-3xl font-bold text-gray-900">
            {value.toLocaleString()}
          </p>
          <span className="text-sm text-gray-500">{unit}</span>
        </div>
        {subtitle && (
          <p className="text-xs text-gray-500">{subtitle}</p>
        )}
      </div>
    </div>
  );
}