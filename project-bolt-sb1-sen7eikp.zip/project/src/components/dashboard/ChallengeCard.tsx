import React from 'react';
import { useChallenges } from '../../hooks/useChallenges';
import { CheckCircle, Target, Plus, Minus } from 'lucide-react';
import type { Challenge } from '../../hooks/useChallenges';

interface ChallengeCardProps {
  challenge: Challenge;
}

export function ChallengeCard({ challenge }: ChallengeCardProps) {
  const { updateChallengeProgress } = useChallenges();

  const handleUpdateProgress = async (increment: number) => {
    const newValue = Math.max(0, challenge.current_value + increment);
    try {
      await updateChallengeProgress(challenge.id, newValue);
    } catch (error) {
      console.error('Failed to update challenge progress:', error);
    }
  };

  const progress = Math.min((challenge.current_value / challenge.target_value) * 100, 100);

  const categoryEmojis: Record<string, string> = {
    workout: '💪',
    nutrition: '🥗',
    steps: '👟',
    water: '💧',
  };

  return (
    <div className={`p-4 rounded-xl border-2 transition-all duration-200 ${
      challenge.completed 
        ? 'border-emerald-200 bg-emerald-50' 
        : 'border-yellow-200 bg-yellow-50'
    }`}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="text-2xl">{categoryEmojis[challenge.category] || '🎯'}</span>
          <div>
            <h4 className="font-bold text-gray-900">{challenge.title}</h4>
            <p className="text-sm text-gray-600">{challenge.description}</p>
          </div>
        </div>
        {challenge.completed && (
          <CheckCircle className="w-6 h-6 text-emerald-500 flex-shrink-0" />
        )}
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-600">Progress</span>
          <span className="font-semibold">
            {challenge.current_value} / {challenge.target_value} {challenge.unit}
          </span>
        </div>
        
        <div className="w-full bg-gray-200 rounded-full h-3">
          <div 
            className={`h-3 rounded-full transition-all duration-300 ${
              challenge.completed 
                ? 'bg-emerald-500' 
                : 'bg-gradient-to-r from-yellow-400 to-orange-500'
            }`}
            style={{ width: `${progress}%` }}
          ></div>
        </div>

        {!challenge.completed && (
          <div className="flex items-center justify-center gap-2 pt-2">
            <button
              onClick={() => handleUpdateProgress(-1)}
              disabled={challenge.current_value <= 0}
              className="p-2 bg-gray-100 hover:bg-gray-200 disabled:opacity-50 disabled:cursor-not-allowed rounded-lg transition-colors"
            >
              <Minus className="w-4 h-4" />
            </button>
            <span className="text-sm text-gray-600 px-4">Update Progress</span>
            <button
              onClick={() => handleUpdateProgress(1)}
              className="p-2 bg-yellow-100 hover:bg-yellow-200 rounded-lg transition-colors"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}