import React, { useState, useEffect } from 'react';
import { useWorkouts } from '../../hooks/useWorkouts';
import { searchExercise, calculateCaloriesBurned } from '../../services/nutritionApi';
import { X, Save, Search } from 'lucide-react';
import { format } from 'date-fns';
import type { Database } from '../../lib/supabase';

type Workout = Database['public']['Tables']['workouts']['Row'];

interface WorkoutFormProps {
  workout?: Workout | null;
  onClose: () => void;
}

export function WorkoutForm({ workout, onClose }: WorkoutFormProps) {
  const { addWorkout, updateWorkout } = useWorkouts();
  const [loading, setLoading] = useState(false);
  const [searchingExercise, setSearchingExercise] = useState(false);
  
  const [formData, setFormData] = useState({
    name: workout?.name || '',
    duration_minutes: workout?.duration_minutes || 30,
    calories_burned: workout?.calories_burned || 0,
    exercise_type: workout?.exercise_type || 'cardio',
    notes: workout?.notes || '',
    date: workout?.date || format(new Date(), 'yyyy-MM-dd'),
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading) return;

    setLoading(true);
    try {
      if (workout) {
        await updateWorkout(workout.id, formData);
      } else {
        await addWorkout(formData);
      }
      onClose();
    } catch (error) {
      console.error('Failed to save workout:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleExerciseSearch = async () => {
    if (!formData.name.trim()) return;
    
    setSearchingExercise(true);
    try {
      const exerciseInfo = await searchExercise(formData.name);
      if (exerciseInfo) {
        const estimatedCalories = calculateCaloriesBurned(formData.name, formData.duration_minutes);
        setFormData(prev => ({
          ...prev,
          calories_burned: estimatedCalories,
          exercise_type: exerciseInfo.category,
        }));
      }
    } catch (error) {
      console.error('Failed to search exercise:', error);
    } finally {
      setSearchingExercise(false);
    }
  };

  const exerciseTypes = [
    { value: 'cardio', label: 'Cardio' },
    { value: 'strength', label: 'Strength Training' },
    { value: 'flexibility', label: 'Flexibility' },
    { value: 'sports', label: 'Sports' },
    { value: 'other', label: 'Other' },
  ];

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-2xl shadow-2xl max-w-md w-full max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-2xl font-bold text-gray-900">
            {workout ? 'Edit Workout' : 'Add New Workout'}
          </h2>
          <button
            onClick={onClose}
            className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Exercise Name
            </label>
            <div className="flex gap-2">
              <input
                type="text"
                value={formData.name}
                onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors"
                placeholder="e.g., Running, Push-ups, Yoga"
                required
              />
              <button
                type="button"
                onClick={handleExerciseSearch}
                disabled={searchingExercise || !formData.name.trim()}
                className="px-3 py-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                title="Auto-estimate calories"
              >
                {searchingExercise ? (
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <Search className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Duration (minutes)
              </label>
              <input
                type="number"
                value={formData.duration_minutes}
                onChange={(e) => setFormData(prev => ({ ...prev, duration_minutes: parseInt(e.target.value) || 0 }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors"
                min="1"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Calories Burned
              </label>
              <input
                type="number"
                value={formData.calories_burned}
                onChange={(e) => setFormData(prev => ({ ...prev, calories_burned: parseInt(e.target.value) || 0 }))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors"
                min="0"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Exercise Type
            </label>
            <select
              value={formData.exercise_type}
              onChange={(e) => setFormData(prev => ({ ...prev, exercise_type: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors"
            >
              {exerciseTypes.map((type) => (
                <option key={type.value} value={type.value}>
                  {type.label}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Date
            </label>
            <input
              type="date"
              value={formData.date}
              onChange={(e) => setFormData(prev => ({ ...prev, date: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Notes (optional)
            </label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors"
              rows={3}
              placeholder="Any additional notes about this workout..."
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 bg-gradient-to-r from-emerald-500 to-blue-500 text-white py-3 px-4 rounded-lg font-semibold hover:from-emerald-600 hover:to-blue-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200 flex items-center justify-center gap-2"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <>
                  <Save className="w-5 h-5" />
                  {workout ? 'Update' : 'Save'} Workout
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}