import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          email: string;
          full_name: string;
          age: number;
          weight: number;
          height: number;
          activity_level: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id: string;
          email: string;
          full_name?: string;
          age?: number;
          weight?: number;
          height?: number;
          activity_level?: string;
        };
        Update: {
          full_name?: string;
          age?: number;
          weight?: number;
          height?: number;
          activity_level?: string;
          updated_at?: string;
        };
      };
      workouts: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          duration_minutes: number;
          calories_burned: number;
          exercise_type: string;
          notes: string;
          date: string;
          created_at: string;
        };
        Insert: {
          user_id: string;
          name: string;
          duration_minutes: number;
          calories_burned: number;
          exercise_type?: string;
          notes?: string;
          date?: string;
        };
        Update: {
          name?: string;
          duration_minutes?: number;
          calories_burned?: number;
          exercise_type?: string;
          notes?: string;
          date?: string;
        };
      };
      meals: {
        Row: {
          id: string;
          user_id: string;
          name: string;
          calories: number;
          protein: number;
          carbs: number;
          fat: number;
          meal_type: string;
          date: string;
          created_at: string;
        };
        Insert: {
          user_id: string;
          name: string;
          calories: number;
          protein?: number;
          carbs?: number;
          fat?: number;
          meal_type?: string;
          date?: string;
        };
        Update: {
          name?: string;
          calories?: number;
          protein?: number;
          carbs?: number;
          fat?: number;
          meal_type?: string;
          date?: string;
        };
      };
    };
  };
};