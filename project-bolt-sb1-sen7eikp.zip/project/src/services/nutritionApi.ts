// Mock nutrition API service - replace with real API integration
interface NutritionInfo {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

interface ExerciseInfo {
  calories_per_minute: number;
  category: string;
}

// Simplified nutrition database for demo purposes
const nutritionDatabase: Record<string, NutritionInfo> = {
  'apple': { calories: 95, protein: 0.5, carbs: 25, fat: 0.3 },
  'banana': { calories: 105, protein: 1.3, carbs: 27, fat: 0.4 },
  'chicken breast': { calories: 231, protein: 43.5, carbs: 0, fat: 5 },
  'rice': { calories: 206, protein: 4.3, carbs: 45, fat: 0.4 },
  'salmon': { calories: 208, protein: 22.1, carbs: 0, fat: 12.4 },
  'pasta': { calories: 220, protein: 8, carbs: 44, fat: 1.1 },
  'bread': { calories: 265, protein: 9, carbs: 49, fat: 3.2 },
  'egg': { calories: 155, protein: 13, carbs: 1.1, fat: 11 },
  'milk': { calories: 150, protein: 8, carbs: 12, fat: 8 },
  'cheese': { calories: 400, protein: 25, carbs: 1, fat: 33 },
};

// Exercise calorie burn rates (calories per minute for average person)
const exerciseDatabase: Record<string, ExerciseInfo> = {
  'running': { calories_per_minute: 12, category: 'cardio' },
  'walking': { calories_per_minute: 4, category: 'cardio' },
  'cycling': { calories_per_minute: 8, category: 'cardio' },
  'swimming': { calories_per_minute: 10, category: 'cardio' },
  'weightlifting': { calories_per_minute: 6, category: 'strength' },
  'yoga': { calories_per_minute: 3, category: 'flexibility' },
  'pilates': { calories_per_minute: 4, category: 'flexibility' },
  'dancing': { calories_per_minute: 5, category: 'cardio' },
  'basketball': { calories_per_minute: 8, category: 'sports' },
  'tennis': { calories_per_minute: 7, category: 'sports' },
};

export async function searchNutrition(query: string): Promise<NutritionInfo | null> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const normalizedQuery = query.toLowerCase().trim();
  
  // Try exact match first
  if (nutritionDatabase[normalizedQuery]) {
    return nutritionDatabase[normalizedQuery];
  }
  
  // Try partial match
  const partialMatch = Object.keys(nutritionDatabase).find(key => 
    key.includes(normalizedQuery) || normalizedQuery.includes(key)
  );
  
  if (partialMatch) {
    return nutritionDatabase[partialMatch];
  }
  
  return null;
}

export async function searchExercise(query: string): Promise<ExerciseInfo | null> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const normalizedQuery = query.toLowerCase().trim();
  
  // Try exact match first
  if (exerciseDatabase[normalizedQuery]) {
    return exerciseDatabase[normalizedQuery];
  }
  
  // Try partial match
  const partialMatch = Object.keys(exerciseDatabase).find(key => 
    key.includes(normalizedQuery) || normalizedQuery.includes(key)
  );
  
  if (partialMatch) {
    return exerciseDatabase[partialMatch];
  }
  
  return null;
}

export function calculateCaloriesBurned(exercise: string, durationMinutes: number): number {
  const exerciseInfo = exerciseDatabase[exercise.toLowerCase()];
  if (exerciseInfo) {
    return Math.round(exerciseInfo.calories_per_minute * durationMinutes);
  }
  // Default estimate if exercise not found
  return Math.round(durationMinutes * 5);
}