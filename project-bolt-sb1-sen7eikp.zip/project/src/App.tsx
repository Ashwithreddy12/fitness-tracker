import React, { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AuthForm } from './components/auth/AuthForm';
import { Navigation } from './components/layout/Navigation';
import { Dashboard } from './components/dashboard/Dashboard';
import { WorkoutList } from './components/workouts/WorkoutList';
import { MealList } from './components/meals/MealList';
import { GoalsList } from './components/goals/GoalsList';
import { AchievementsList } from './components/achievements/AchievementsList';
import { Statistics } from './components/statistics/Statistics';
import { Settings } from './components/settings/Settings';
import { ProfileForm } from './components/profile/ProfileForm';

function AppContent() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-blue-50 to-purple-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading FitTracker...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthForm />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'workouts':
        return <WorkoutList />;
      case 'meals':
        return <MealList />;
      case 'goals':
        return <GoalsList />;
      case 'achievements':
        return <AchievementsList />;
      case 'statistics':
        return <Statistics />;
      case 'settings':
        return <Settings />;
      case 'profile':
        return <ProfileForm />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-blue-50 to-purple-50">
      <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="py-8">
        {renderContent()}
      </main>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;