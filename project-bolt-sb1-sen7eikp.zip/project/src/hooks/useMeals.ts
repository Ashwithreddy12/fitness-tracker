import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import type { Database } from '../lib/supabase';

type Meal = Database['public']['Tables']['meals']['Row'];
type MealInsert = Database['public']['Tables']['meals']['Insert'];
type MealUpdate = Database['public']['Tables']['meals']['Update'];

export function useMeals() {
  const [meals, setMeals] = useState<Meal[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  const fetchMeals = async () => {
    if (!user) return;
    
    try {
      const { data, error } = await supabase
        .from('meals')
        .select('*')
        .eq('user_id', user.id)
        .order('date', { ascending: false });
      
      if (error) throw error;
      setMeals(data || []);
    } catch (error) {
      console.error('Error fetching meals:', error);
    } finally {
      setLoading(false);
    }
  };

  const addMeal = async (meal: Omit<MealInsert, 'user_id'>) => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('meals')
        .insert({ ...meal, user_id: user.id })
        .select()
        .single();
      
      if (error) throw error;
      setMeals(prev => [data, ...prev]);
      return data;
    } catch (error) {
      console.error('Error adding meal:', error);
      throw error;
    }
  };

  const updateMeal = async (id: string, updates: MealUpdate) => {
    try {
      const { data, error } = await supabase
        .from('meals')
        .update(updates)
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      setMeals(prev => prev.map(m => m.id === id ? data : m));
      return data;
    } catch (error) {
      console.error('Error updating meal:', error);
      throw error;
    }
  };

  const deleteMeal = async (id: string) => {
    try {
      const { error } = await supabase
        .from('meals')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
      setMeals(prev => prev.filter(m => m.id !== id));
    } catch (error) {
      console.error('Error deleting meal:', error);
      throw error;
    }
  };

  useEffect(() => {
    fetchMeals();
  }, [user]);

  return {
    meals,
    loading,
    addMeal,
    updateMeal,
    deleteMeal,
    refreshMeals: fetchMeals,
  };
}