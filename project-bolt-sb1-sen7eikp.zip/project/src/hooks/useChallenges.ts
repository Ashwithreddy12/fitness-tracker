import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';

export interface Challenge {
  id: string;
  user_id: string;
  title: string;
  description: string;
  target_value: number;
  current_value: number;
  unit: string;
  category: 'workout' | 'nutrition' | 'steps' | 'water';
  date: string;
  completed: boolean;
  created_at: string;
}

const dailyChallenges = [
  { title: 'Burn 300 Calories', description: 'Complete any workout that burns at least 300 calories', target_value: 300, unit: 'calories', category: 'workout' as const },
  { title: 'Walk 8000 Steps', description: 'Take at least 8000 steps today', target_value: 8000, unit: 'steps', category: 'steps' as const },
  { title: 'Drink 8 Glasses of Water', description: 'Stay hydrated with 8 glasses of water', target_value: 8, unit: 'glasses', category: 'water' as const },
  { title: '30-Minute Workout', description: 'Complete a workout session lasting at least 30 minutes', target_value: 30, unit: 'minutes', category: 'workout' as const },
  { title: 'Eat 5 Servings of Fruits/Vegetables', description: 'Include 5 servings of fruits or vegetables in your meals', target_value: 5, unit: 'servings', category: 'nutrition' as const },
  { title: 'Complete 2 Workouts', description: 'Finish 2 different workout sessions today', target_value: 2, unit: 'workouts', category: 'workout' as const },
];

export function useChallenges() {
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  const fetchChallenges = async () => {
    if (!user) return;
    
    try {
      const today = format(new Date(), 'yyyy-MM-dd');
      const { data, error } = await supabase
        .from('challenges')
        .select('*')
        .eq('user_id', user.id)
        .eq('date', today);
      
      if (error) throw error;
      
      // If no challenges for today, create a random one
      if (!data || data.length === 0) {
        await createDailyChallenge();
      } else {
        setChallenges(data);
      }
    } catch (error) {
      console.error('Error fetching challenges:', error);
    } finally {
      setLoading(false);
    }
  };

  const createDailyChallenge = async () => {
    if (!user) return;

    try {
      const today = format(new Date(), 'yyyy-MM-dd');
      const randomChallenge = dailyChallenges[Math.floor(Math.random() * dailyChallenges.length)];
      
      const { data, error } = await supabase
        .from('challenges')
        .insert({
          user_id: user.id,
          title: randomChallenge.title,
          description: randomChallenge.description,
          target_value: randomChallenge.target_value,
          current_value: 0,
          unit: randomChallenge.unit,
          category: randomChallenge.category,
          date: today,
          completed: false,
        })
        .select()
        .single();
      
      if (error) throw error;
      setChallenges([data]);
    } catch (error) {
      console.error('Error creating daily challenge:', error);
    }
  };

  const updateChallengeProgress = async (id: string, progress: number) => {
    try {
      const challenge = challenges.find(c => c.id === id);
      if (!challenge) return;

      const newValue = Math.min(progress, challenge.target_value);
      const completed = newValue >= challenge.target_value;

      const { data, error } = await supabase
        .from('challenges')
        .update({ 
          current_value: newValue,
          completed: completed
        })
        .eq('id', id)
        .select()
        .single();
      
      if (error) throw error;
      setChallenges(prev => prev.map(c => c.id === id ? data : c));
      return data;
    } catch (error) {
      console.error('Error updating challenge:', error);
      throw error;
    }
  };

  useEffect(() => {
    fetchChallenges();
  }, [user]);

  return {
    challenges,
    loading,
    updateChallengeProgress,
    refreshChallenges: fetchChallenges,
  };
}