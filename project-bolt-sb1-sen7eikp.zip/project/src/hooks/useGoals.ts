import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export interface Goal {
  id: string;
  user_id: string;
  title: string;
  description: string;
  target_value: number;
  current_value: number;
  unit: string;
  category: 'workout' | 'nutrition' | 'weight' | 'custom';
  deadline: string;
  completed: boolean;
  created_at: string;
}

export function useGoals() {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  // ✅ Fetch all goals for logged-in user
  const fetchGoals = async () => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('goals')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setGoals(data || []);
    } catch (err) {
      console.error('Error fetching goals:', err);
    } finally {
      setLoading(false);
    }
  };

  // ✅ Add a new goal
  const addGoal = async (goal: {
    title: string;
    description: string;
    target_value: number;
    unit: string;
    category: 'workout' | 'nutrition' | 'weight' | 'custom';
    deadline: string;
  }) => {
    if (!user) return;

    try {
      const { data, error } = await supabase
        .from('goals')
        .insert({
          ...goal,
          user_id: user.id,
          current_value: 0, // always start at 0
          completed: false, // default to false
        })
        .select()
        .single();

      if (error) throw error;

      setGoals(prev => [data as Goal, ...prev]);
      return data as Goal;
    } catch (err) {
      console.error('Error adding goal:', err);
      throw err;
    }
  };

  // ✅ Update an existing goal
  const updateGoal = async (id: string, updates: Partial<Goal>) => {
    try {
      const { data, error } = await supabase
        .from('goals')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      setGoals(prev => prev.map(g => (g.id === id ? (data as Goal) : g)));
      return data as Goal;
    } catch (err) {
      console.error('Error updating goal:', err);
      throw err;
    }
  };

  // ✅ Delete a goal
  const deleteGoal = async (id: string) => {
    try {
      const { error } = await supabase.from('goals').delete().eq('id', id);

      if (error) throw error;

      setGoals(prev => prev.filter(g => g.id !== id));
    } catch (err) {
      console.error('Error deleting goal:', err);
      throw err;
    }
  };

  useEffect(() => {
    fetchGoals();
  }, [user]);

  return {
    goals,
    loading,
    addGoal,
    updateGoal,
    deleteGoal,
    refreshGoals: fetchGoals,
  };
}
