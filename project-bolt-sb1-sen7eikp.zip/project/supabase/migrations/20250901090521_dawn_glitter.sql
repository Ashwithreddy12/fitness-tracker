/*
  # Add Goals, Challenges, and Settings Tables

  1. New Tables
    - `goals`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `title` (text)
      - `description` (text)
      - `target_value` (integer)
      - `current_value` (integer)
      - `unit` (text)
      - `category` (text)
      - `deadline` (date)
      - `completed` (boolean)
      - `created_at` (timestamp)
    
    - `challenges`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `title` (text)
      - `description` (text)
      - `target_value` (integer)
      - `current_value` (integer)
      - `unit` (text)
      - `category` (text)
      - `date` (date)
      - `completed` (boolean)
      - `created_at` (timestamp)
    
    - `user_settings`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references profiles)
      - `notifications_enabled` (boolean)
      - `daily_calorie_goal` (integer)
      - `weekly_workout_goal` (integer)
      - `theme` (text)
      - `units` (text)
      - `privacy_level` (text)
      - `auto_sync` (boolean)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Security
    - Enable RLS on all new tables
    - Add policies for authenticated users to manage their own data
*/

-- Create goals table
CREATE TABLE IF NOT EXISTS goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text DEFAULT '',
  target_value integer NOT NULL DEFAULT 1,
  current_value integer DEFAULT 0,
  unit text DEFAULT 'times',
  category text DEFAULT 'custom',
  deadline date NOT NULL,
  completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create challenges table
CREATE TABLE IF NOT EXISTS challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title text NOT NULL,
  description text DEFAULT '',
  target_value integer NOT NULL DEFAULT 1,
  current_value integer DEFAULT 0,
  unit text DEFAULT 'times',
  category text DEFAULT 'workout',
  date date NOT NULL DEFAULT CURRENT_DATE,
  completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Create user_settings table
CREATE TABLE IF NOT EXISTS user_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  notifications_enabled boolean DEFAULT true,
  daily_calorie_goal integer DEFAULT 2000,
  weekly_workout_goal integer DEFAULT 3,
  theme text DEFAULT 'light',
  units text DEFAULT 'metric',
  privacy_level text DEFAULT 'private',
  auto_sync boolean DEFAULT true,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id)
);

-- Enable RLS
ALTER TABLE goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

-- Goals policies
CREATE POLICY "Users can manage own goals"
  ON goals
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Challenges policies
CREATE POLICY "Users can manage own challenges"
  ON challenges
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- User settings policies
CREATE POLICY "Users can manage own settings"
  ON user_settings
  FOR ALL
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Add indexes for performance
CREATE INDEX IF NOT EXISTS idx_goals_user_id ON goals(user_id);
CREATE INDEX IF NOT EXISTS idx_goals_deadline ON goals(deadline);
CREATE INDEX IF NOT EXISTS idx_challenges_user_id ON challenges(user_id);
CREATE INDEX IF NOT EXISTS idx_challenges_date ON challenges(date);
CREATE INDEX IF NOT EXISTS idx_user_settings_user_id ON user_settings(user_id);